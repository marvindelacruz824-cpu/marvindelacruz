MARVIN DELA CRUZ — PERSONAL LINK-IN-BIO WEBSITE

Files:
- index.html: complete responsive website

Preview:
1. Extract the ZIP.
2. Open index.html in a browser.

Publish:
Upload index.html to a static website host such as GitHub Pages or Vercel.

Links included:
Facebook: https://facebook.com/marvscdelacruz
Instagram: https://instagram.com/saiasahi
TikTok: https://tiktok.com/@saiasahi
LinkedIn: https://linkedin.com/in/marvincdelacruz
Gmail: mailto:marvindelacruz824@gmail.com

The website uses a beige minimalist design and adapts to phones, tablets, and desktops.
